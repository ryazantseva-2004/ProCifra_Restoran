package com.example.prostochek;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class SplitActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_split);

        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button equalSplitBtn = findViewById(R.id.equalSplitBtn);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button manualSplitBtn = findViewById(R.id.manualSplitBtn);

        String receiptText = getIntent().getStringExtra("receiptText");

        equalSplitBtn.setOnClickListener(v -> {
            Intent intent = new Intent(SplitActivity.this, EqualSplitActivity.class);
            intent.putExtra("receiptText", receiptText);
            startActivity(intent);
        });

        manualSplitBtn.setOnClickListener(v -> {
            Intent intent = new Intent(SplitActivity.this, ManualSplitActivity.class);
            intent.putExtra("receiptText", receiptText);
            startActivity(intent);
        });
    }
}
