package com.example.prostochek;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import com.example.prostochek.EqualSplitActivity.ReceiptItem;

public class ManualSplitAdapter extends RecyclerView.Adapter<ManualSplitAdapter.ViewHolder> {



    private final List<EqualSplitActivity.ReceiptItem> items;
    private final int peopleCount;
    private final Map<Integer, List<EqualSplitActivity.ReceiptItem>> personItemsMap;

    public ManualSplitAdapter(List<ReceiptItem> items, int peopleCount, Map<Integer, List<ReceiptItem>> personItemsMap) {
        this.items = items;
        this.peopleCount = peopleCount;
        this.personItemsMap = personItemsMap;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_manual_split, parent, false);
        return new ViewHolder(view);
    }

    // Исправленный onBindViewHolder:
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ReceiptItem item = items.get(position);
        holder.itemName.setText(item.getName());
        holder.itemPrice.setText(String.format(Locale.US, "%.2f", item.getPrice()));

        // Очищаем предыдущие слушатели
        holder.personCheckboxes.forEach((personNum, checkBox) -> {
            checkBox.setOnCheckedChangeListener(null);
            checkBox.setChecked(false);
        });

        // Устанавливаем слушатели для каждого CheckBox
        for (Map.Entry<Integer, CheckBox> entry : holder.personCheckboxes.entrySet()) {
            Integer personNum = entry.getKey();
            CheckBox checkBox = entry.getValue();
            checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) {
                    // Удаляем товар из всех других списков
                    for (int i = 1; i <= peopleCount; i++) {
                        if (i != personNum && personItemsMap.containsKey(i)) {
                            Objects.requireNonNull(personItemsMap.get(i)).remove(item);
                        }
                    }
                    // Добавляем товар в список текущего человека
                    if (personItemsMap.containsKey(personNum)) {
                        List<ReceiptItem> personItems = Objects.requireNonNull(personItemsMap.get(personNum));
                        if (!personItems.contains(item)) {
                            personItems.add(item);
                        }
                    }
                } else if (personItemsMap.containsKey(personNum)) {
                    Objects.requireNonNull(personItemsMap.get(personNum)).remove(item);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView itemName;
        public TextView itemPrice;
        public Map<Integer, CheckBox> personCheckboxes;

        public ViewHolder(View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.itemName);
            itemPrice = itemView.findViewById(R.id.itemPrice);

            // Инициализируем CheckBox для каждого человека
            personCheckboxes = new HashMap<>();
            personCheckboxes.put(1, itemView.findViewById(R.id.person1CheckBox));
            personCheckboxes.put(2, itemView.findViewById(R.id.person2CheckBox));
            personCheckboxes.put(3, itemView.findViewById(R.id.person3CheckBox));
            personCheckboxes.put(4, itemView.findViewById(R.id.person4CheckBox));

            // Скрываем лишние CheckBox если людей меньше
            for (Map.Entry<Integer, CheckBox> entry : personCheckboxes.entrySet()) {
                if (entry.getKey() > 4) { // У нас только 4 CheckBox в layout
                    entry.getValue().setVisibility(View.GONE);
                }
            }
        }
    }
}
