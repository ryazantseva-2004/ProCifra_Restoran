package com.example.prostochek;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.googlecode.tesseract.android.TessBaseAPI;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Objects;

public class OcrProcessor extends AppCompatActivity {

    private static final String TESS_DATA_PATH = "/tesseract/";
    private static final String DEFAULT_LANGUAGE = "rus";

    private ProgressBar progressBar;
    private TextView resultText;
    private Button splitBtn;
    private Bitmap bitmap;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ocr_processor);

        progressBar = findViewById(R.id.progressBar);
        resultText = findViewById(R.id.resultText);
        splitBtn = findViewById(R.id.splitBtn);

        byte[] byteArray = getIntent().getByteArrayExtra("image");
        bitmap = BitmapFactory.decodeByteArray(byteArray, 0, Objects.requireNonNull(byteArray).length);

        new OcrTask().execute();
    }

    @SuppressLint("StaticFieldLeak")
    private class OcrTask extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
            resultText.setText(R.string.processing_receipt);
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                // Проверяем и копируем тренировочные данные Tesseract
                prepareTessData();

                TessBaseAPI tessBaseAPI = new TessBaseAPI();
                String dataPath = getFilesDir() + TESS_DATA_PATH;

                if (!tessBaseAPI.init(dataPath, DEFAULT_LANGUAGE)) {
                    return "Could not initialize Tesseract.";
                }

                tessBaseAPI.setImage(bitmap);
                String result = tessBaseAPI.getUTF8Text();
                tessBaseAPI.end();

                return result;
            } catch (Exception e) {
                    Log.e("OcrProcessor", "Error during OCR processing", e);
                    return getString(R.string.ocr_error) + e.getMessage();
                }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            progressBar.setVisibility(View.GONE);
            resultText.setText(result);
            splitBtn.setVisibility(View.VISIBLE);

            splitBtn.setOnClickListener(v -> {
                Intent intent = new Intent(OcrProcessor.this, SplitActivity.class);
                intent.putExtra("receiptText", result);
                startActivity(intent);
                finish();
            });
        }
    }

    private void prepareTessData() throws IOException {
        File dir = new File(getFilesDir() + TESS_DATA_PATH + "tessdata/");
        if (!dir.exists()) {
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
        }

        String[] files = getAssets().list("tessdata");
        if (files != null) {
            for (String file : files) {
                String path = getFilesDir() + TESS_DATA_PATH + "tessdata/" + file;
                if (!new File(path).exists()) {
                    InputStream in = getAssets().open("tessdata/" + file);
                    OutputStream out = new FileOutputStream(path);

                    byte[] buffer = new byte[1024];
                    int read;
                    while ((read = in.read(buffer)) != -1) {
                        out.write(buffer, 0, read);
                    }

                    in.close();
                    out.flush();
                    out.close();
                }
            }
        }
    }
}