package com.example.prostochek;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EqualSplitActivity extends AppCompatActivity {

    private EditText peopleCountEditText;
    private Button shareBtn;
    private TextView resultTextView;

    private List<ReceiptItem> items;
    private double totalAmount;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_equal_split);

        TextView receiptTextView = findViewById(R.id.receiptTextView);
        peopleCountEditText = findViewById(R.id.peopleCountEditText);
        Button calculateBtn = findViewById(R.id.calculateBtn);
        shareBtn = findViewById(R.id.shareBtn);
        resultTextView = findViewById(R.id.resultTextView);

        String receiptText = getIntent().getStringExtra("receiptText");
        receiptTextView.setText(receiptText);

        // Парсим чек
        if (receiptText != null) {
            parseReceipt(receiptText);
        }

        calculateBtn.setOnClickListener(v -> calculateSplit());
        shareBtn.setOnClickListener(v -> shareResult());
    }

    private void parseReceipt(String receiptText) {
        items = new ArrayList<>();
        totalAmount = 0.0;

        // Простой парсер для извлечения товаров и цен
        // В реальном приложении нужно использовать более сложную логику
        String[] lines = receiptText.split("\n");
        Pattern pattern = Pattern.compile("(.+?)\\s+(\\d+\\.\\d{2})");

        for (String line : lines) {
            Matcher matcher = pattern.matcher(line);
            if (matcher.find()) {
                String name = Objects.requireNonNull(matcher.group(1)).trim();
                double price = Double.parseDouble(Objects.requireNonNull(matcher.group(2)));
                items.add(new ReceiptItem(name, price));
                totalAmount += price;
            }
        }

        // Если не удалось распарсить, просто показываем общую сумму
        if (items.isEmpty()) {
            Pattern totalPattern = Pattern.compile("ИТОГО\\s+(\\d+\\.\\d{2})", Pattern.CASE_INSENSITIVE);
            Matcher totalMatcher = totalPattern.matcher(receiptText);
            if (totalMatcher.find()) {
                totalAmount = Double.parseDouble(Objects.requireNonNull(totalMatcher.group(1)));
            }
        }
    }

    private void calculateSplit() {
        String peopleCountStr = peopleCountEditText.getText().toString();
        if (peopleCountStr.isEmpty()) {
            Toast.makeText(this, "Please enter number of people", Toast.LENGTH_SHORT).show();
            return;
        }

        int peopleCount = Integer.parseInt(peopleCountStr);
        if (peopleCount <= 0) {
            Toast.makeText(this, "Number of people must be positive", Toast.LENGTH_SHORT).show();
            return;
        }

        StringBuilder result = getStringBuilder(peopleCount);

        resultTextView.setText(result.toString());
        shareBtn.setVisibility(View.VISIBLE);
    }

    @NonNull
    private StringBuilder getStringBuilder(int peopleCount) {
        double amountPerPerson = totalAmount / peopleCount;
        DecimalFormat df = new DecimalFormat("#.00");

        StringBuilder result = new StringBuilder();
        result.append("Original receipt total: ").append(df.format(totalAmount)).append("\n\n");
        result.append("Split between ").append(peopleCount).append(" people\n");
        result.append("Each person pays: ").append(df.format(amountPerPerson)).append("\n\n");
        result.append("Items:\n");

        for (ReceiptItem item : items) {
            result.append(item.getName()).append(" - ").append(df.format(item.getPrice())).append("\n");
        }
        return result;
    }

    private void shareResult() {
        String shareText = resultTextView.getText().toString();
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);
        startActivity(Intent.createChooser(shareIntent, "Share receipt split"));
    }

    public static class ReceiptItem {
        private final String name;
        private final double price;

        public ReceiptItem(String name, double price) {
            this.name = name;
            this.price = price;
        }

        public String getName() {
            return name;
        }

        public double getPrice() {
            return price;
        }
    }
}
