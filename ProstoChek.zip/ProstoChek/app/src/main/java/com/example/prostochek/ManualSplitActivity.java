package com.example.prostochek;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.example.prostochek.EqualSplitActivity.ReceiptItem;

public class ManualSplitActivity extends AppCompatActivity {
    @SuppressLint("MutableImplicitPendingIntent")
    private TextView receiptTextView;
    private EditText peopleCountEditText;
    @SuppressLint("MutableImplicitPendingIntent")
    private Button setupBtn;
    @SuppressLint("MutableImplicitPendingIntent")
    private int peopleCount;
    private RecyclerView itemsRecyclerView;
    private Button calculateBtn;
    private Button shareBtn;
    private TextView resultTextView;
    @SuppressLint("MutableImplicitPendingIntent")
    private ManualSplitAdapter adapter;
    private final List<EqualSplitActivity.ReceiptItem> items = new ArrayList<>();
    private final Map<Integer, List<EqualSplitActivity.ReceiptItem>> personItemsMap = new HashMap<>();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual_split);

        receiptTextView = findViewById(R.id.receiptTextView);
        peopleCountEditText = findViewById(R.id.peopleCountEditText);
        setupBtn = findViewById(R.id.setupBtn);
        itemsRecyclerView = findViewById(R.id.itemsRecyclerView);
        calculateBtn = findViewById(R.id.calculateBtn);
        shareBtn = findViewById(R.id.shareBtn);
        resultTextView = findViewById(R.id.resultTextView);

        String receiptText = getIntent().getStringExtra("receiptText");
        receiptTextView.setText(receiptText);

        // Парсим чек
        parseReceipt(Objects.requireNonNull(receiptText));

        setupBtn.setOnClickListener(v -> setupManualSplit());
        calculateBtn.setOnClickListener(v -> calculateManualSplit());
        shareBtn.setOnClickListener(v -> shareResult());
    }

    private void parseReceipt(String receiptText) {
        items.clear();

        // Простой парсер для извлечения товаров и цен
        String[] lines = receiptText.split("\n");
        Pattern pattern = Pattern.compile("(.+?)\\s+(\\d+\\.\\d{2})");

        for (String line : lines) {
            Matcher matcher = pattern.matcher(line);
            if (matcher.find()) {
                String name = Objects.requireNonNull(matcher.group(1)).trim();
                double price = Double.parseDouble(Objects.requireNonNull(matcher.group(2)));
                items.add(new ReceiptItem(name, price));
            }
        }
    }

    private void setupManualSplit() {
        String peopleCountStr = peopleCountEditText.getText().toString();
        if (peopleCountStr.isEmpty()) {
            Toast.makeText(this, "Please enter number of people", Toast.LENGTH_SHORT).show();
            return;
        }

        peopleCount = Integer.parseInt(peopleCountStr);
        if (peopleCount <= 0) {
            Toast.makeText(this, "Number of people must be positive", Toast.LENGTH_SHORT).show();
            return;
        }

        // Очищаем предыдущие данные
        personItemsMap.clear();
        for (int i = 1; i <= peopleCount; i++) {
            personItemsMap.put(i, new ArrayList<>());
        }

        adapter = new ManualSplitAdapter(items, peopleCount, personItemsMap);
        itemsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        itemsRecyclerView.setAdapter(adapter);

        calculateBtn.setVisibility(View.VISIBLE);
    }

    private void calculateManualSplit() {
        if (personItemsMap == null || personItemsMap.isEmpty()) {
            Toast.makeText(this, "Please setup split first", Toast.LENGTH_SHORT).show();
            return;
        }

        DecimalFormat df = new DecimalFormat("#.00");
        StringBuilder result = new StringBuilder();
        result.append("Manual split results:\n\n");

        double total = 0.0;
        for (ReceiptItem item : items) {
            total += item.getPrice();
        }

        result.append("Total amount: ").append(df.format(total)).append("\n\n");

        for (Map.Entry<Integer, List<ReceiptItem>> entry : personItemsMap.entrySet()) {
            int personNumber = entry.getKey();
            List<ReceiptItem> personItems = entry.getValue();

            if (personItems.isEmpty()) continue;

            double personTotal = 0.0;
            result.append("Person ").append(personNumber).append(":\n");

            for (ReceiptItem item : personItems) {
                result.append("- ").append(item.getName()).append(": ").append(df.format(item.getPrice())).append("\n");
                personTotal += item.getPrice();
            }

            result.append("Total: ").append(df.format(personTotal)).append("\n\n");
        }

        resultTextView.setText(result.toString());
        shareBtn.setVisibility(View.VISIBLE);
    }

    private void shareResult() {
        String shareText = resultTextView.getText().toString();
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);
        startActivity(Intent.createChooser(shareIntent, "Share manual split"));
    }


}